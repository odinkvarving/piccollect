package Home;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;


public class Controller {

    @FXML
    private Button buttonSignUp;
    @FXML
    private BorderPane borderPane;
    @FXML
    private Pane signUpPane;
    @FXML
    private Pane loginPane;
    @FXML
    private AnchorPane searchAnchorPane;

    public void handleSignUpButtonPressed(){
        borderPane.setCenter(signUpPane);
    }

}
